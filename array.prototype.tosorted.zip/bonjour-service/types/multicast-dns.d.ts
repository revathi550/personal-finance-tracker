declare module 'multicast-dns' {
    function init(opts: { [key: string]: any })
    export = init
}