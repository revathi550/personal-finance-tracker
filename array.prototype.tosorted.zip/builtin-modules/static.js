'use strict';
module.exports = require('./builtin-modules');
