# Installation
> `npm install --save @types/q`

# Summary
This package contains type definitions for q (https://github.com/kriskowal/q).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/q.

### Additional Details
 * Last updated: Tue, 07 Nov 2023 20:08:00 GMT
 * Dependencies: none

# Credits
These definitions were written by [Barrie Nemetchek](https://github.com/bnemetchek), [Andrew Gaspar](https://github.com/AndrewGaspar), [John Reilly](https://github.com/johnnyreilly), [Michel Boudreau](https://github.com/mboudreau), and [TeamworkGuy2](https://github.com/TeamworkGuy2).
