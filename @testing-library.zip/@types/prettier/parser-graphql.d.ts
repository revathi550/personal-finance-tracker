import { Parser } from './';

declare const parser: {
    parsers: {
        graphql: Parser;
    };
};
export = parser;
