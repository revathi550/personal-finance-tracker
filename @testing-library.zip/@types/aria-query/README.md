# Installation
> `npm install --save @types/aria-query`

# Summary
This package contains type definitions for aria-query (https://github.com/A11yance/aria-query#readme).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/aria-query.

### Additional Details
 * Last updated: Mon, 06 Nov 2023 22:41:04 GMT
 * Dependencies: none

# Credits
These definitions were written by [Sebastian Silbermann](https://github.com/eps1lon).
