# Installation
> `npm install --save @types/istanbul-lib-report`

# Summary
This package contains type definitions for istanbul-lib-report (https://istanbul.js.org).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/istanbul-lib-report.

### Additional Details
 * Last updated: Tue, 07 Nov 2023 03:09:37 GMT
 * Dependencies: [@types/istanbul-lib-coverage](https://npmjs.com/package/@types/istanbul-lib-coverage)

# Credits
These definitions were written by [Jason Cheatham](https://github.com/jason0x43), and [Zacharias Björngren](https://github.com/zache).
