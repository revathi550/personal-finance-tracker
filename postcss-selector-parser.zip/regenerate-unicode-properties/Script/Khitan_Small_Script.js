const set = require('regenerate')(0x16FE4, 0x18CFF);
set.addRange(0x18B00, 0x18CD5);
exports.characters = set;
