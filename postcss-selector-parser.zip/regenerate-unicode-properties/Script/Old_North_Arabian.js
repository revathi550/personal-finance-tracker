const set = require('regenerate')();
set.addRange(0x10A80, 0x10A9F);
exports.characters = set;
