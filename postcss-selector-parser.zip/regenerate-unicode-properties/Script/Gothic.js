const set = require('regenerate')();
set.addRange(0x10330, 0x1034A);
exports.characters = set;
