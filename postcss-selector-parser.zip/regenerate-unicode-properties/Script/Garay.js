const set = require('regenerate')();
set.addRange(0x10D40, 0x10D65).addRange(0x10D69, 0x10D85).addRange(0x10D8E, 0x10D8F);
exports.characters = set;
