const set = require('regenerate')(0x2029);

exports.characters = set;
