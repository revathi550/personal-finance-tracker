"use strict";
// @ts-ignore
try {
    self['workbox:broadcast-update:6.6.0'] && _();
}
catch (e) { }
