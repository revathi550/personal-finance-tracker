// @ts-ignore
try{self['workbox:cacheable-response:6.6.1']&&_()}catch(e){}