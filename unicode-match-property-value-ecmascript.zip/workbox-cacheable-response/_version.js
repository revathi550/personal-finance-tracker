"use strict";
// @ts-ignore
try {
    self['workbox:cacheable-response:6.6.0'] && _();
}
catch (e) { }
