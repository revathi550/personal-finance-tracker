import '../../_version.js';
export declare const messageGenerator: ((code: string, ...args: any[]) => string) | ((code: string, details?: {}) => string);
