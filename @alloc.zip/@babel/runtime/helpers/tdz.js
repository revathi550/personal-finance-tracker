function _tdzError(e) {
  throw new ReferenceError(e + " is not defined - temporal dead zone");
}
module.exports = _tdzError, module.exports.__esModule = true, module.exports["default"] = module.exports;