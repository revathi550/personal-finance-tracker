function _AwaitValue(t) {
  this.wrapped = t;
}
module.exports = _AwaitValue, module.exports.__esModule = true, module.exports["default"] = module.exports;