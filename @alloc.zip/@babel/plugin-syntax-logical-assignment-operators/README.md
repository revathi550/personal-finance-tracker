# @babel/plugin-syntax-logical-assignment-operators

> Allow parsing of the logical assignment operators

See our website [@babel/plugin-syntax-logical-assignment-operators](https://babeljs.io/docs/en/next/babel-plugin-syntax-logical-assignment-operators.html) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-syntax-logical-assignment-operators
```

or using yarn:

```sh
yarn add @babel/plugin-syntax-logical-assignment-operators --dev
```
