// TODO: Remove in Babel 8

module.exports = require("@babel/helper-compilation-targets").unreleasedLabels;
