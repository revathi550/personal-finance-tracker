export declare function suppressAsync(): Promise<void>;
//# sourceMappingURL=suppress.d.ts.map