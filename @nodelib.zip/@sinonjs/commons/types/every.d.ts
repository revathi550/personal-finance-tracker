declare function _exports(obj: object, fn: Function): boolean;
export = _exports;
